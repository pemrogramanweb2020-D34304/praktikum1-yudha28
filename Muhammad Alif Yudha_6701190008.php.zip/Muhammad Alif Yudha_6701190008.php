<?php
$c = "*";
	for($a = 0; $a < 5; $a++){
		for($b = 5; $b > $a; $b- - ){
			echo $c;
		}
		echo "<br>";
	}
	?>